﻿namespace SharedTrip.Models.Trips
{
    public class TripDetailsViewModel : AllTripsViewModel
    {
        public string ImagePath { get; set; }
        public string Description { get; set; }
    }
}
