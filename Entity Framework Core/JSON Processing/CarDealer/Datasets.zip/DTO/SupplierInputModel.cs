﻿namespace CarDealer.DTO
{
    public class SupplierInputModel
    {
        public string Name { get; set; }
        public bool isImporter { get; set; }

    }
}
