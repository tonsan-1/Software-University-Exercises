﻿namespace ProductShop.DTO
{
    public class CategoryProductInputModel
    {
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
    }
}
