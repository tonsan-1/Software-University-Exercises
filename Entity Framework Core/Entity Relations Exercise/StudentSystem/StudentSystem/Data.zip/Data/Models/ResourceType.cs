﻿namespace P01_StudentSystem.Data.Models
{
    public enum ResourceType
    {
        Video = 1,
        Presentation,
        Document,
        Other
    }
}